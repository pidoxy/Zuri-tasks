
def addIntegers(int1, int2):
     result = int1 + int2
     print("The added result is" + " " + str(result))

addIntegers(1, 2)